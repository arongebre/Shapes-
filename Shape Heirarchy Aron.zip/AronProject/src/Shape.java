// Base class representing a generic shape
public class Shape {
    private String color;

    public Shape(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void displayColor() {
        System.out.println("Color: " + color);
    }

    public double calculateArea() {
        return 0.0; // Default implementation, to be overridden by subclasses
    }

    public double calculatePerimeter() {
        return 0.0; // Default implementation, to be overridden by subclasses
    }
}
