import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        // Create instances of different shapes
        Circle circle = new Circle(5.0, "blue");
        Rectangle rectangle = new Rectangle(4.0, 6.0, "red");
        Triangle triangle = new Triangle(3.0, 8.0,9.0,5.0, "green");

        // Get user inputs for the color of the shapes
        System.out.print("Enter color for circle (or enter 1 for default color 'blue'): ");
        String circleColor = scanner.nextLine();
        if (!circleColor.equals("1")) {
            circle.setColor(circleColor);
        }

        System.out.print("Enter color for rectangle (or enter 1 for default color 'red'): ");
        String rectangleColor = scanner.nextLine();
        if (!rectangleColor.equals("1")) {
            rectangle.setColor(rectangleColor);
        }

        System.out.print("Enter color for triangle (or enter 1 for default color 'green'): ");
        String triangleColor = scanner.nextLine();
        if (!triangleColor.equals("1")) {
            triangle.setColor(triangleColor);
        }
        // Calculate and display the information for each shape
        circle.displayColor();
        System.out.println("Area: " + circle.calculateArea());
        System.out.println("Perimeter: " + circle.calculatePerimeter());

        System.out.println();

        rectangle.displayColor();
        System.out.println("Area: " + rectangle.calculateArea());
        System.out.println("Perimeter: " + rectangle.calculatePerimeter());

        System.out.println();

        triangle.displayColor();
        System.out.println("Area: " + triangle.calculateArea());
        System.out.println("Perimeter: "+triangle.calculatePerimeter());
        scanner.close();

    }
}